/*
 * Copyright © 2013 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that copyright
 * notice and this permission notice appear in supporting documentation, and
 * that the name of the copyright holders not be used in advertising or
 * publicity pertaining to distribution of the software without specific,
 * written prior permission.  The copyright holders make no representations
 * about the suitability of this software for any purpose.  It is provided "as
 * is" without express or implied warranty.
 *
 * THE COPYRIGHT HOLDERS DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL THE COPYRIGHT HOLDERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THIS SOFTWARE.
 */

#ifndef _BUSFAULT_H_
#define _BUSFAULT_H_

#include <dix-config.h>

#include <X11/Xdefs.h>

#include "include/misc.h"                         /* for TRUE/FALSE */
#include <setjmp.h>

typedef void (*busfault_notify_ptr) (void *context);

#ifdef HAVE_SIGACTION

#include <sys/types.h>

struct busfault *
busfault_register_mmap(void *addr, size_t size, busfault_notify_ptr notify, void *context);

void
busfault_unregister(struct busfault *busfault);

/*
 * If jmp is non-NULL when a SIGBUS hits this mapping, the handler
 * siglongjmps there instead of remapping and retrying the faulting
 * instruction. Callers must use sigsetjmp(..., 1).
 * Pass NULL to clear.
 */
void
busfault_set_jmp(struct busfault *busfault, sigjmp_buf *jmp);

void
busfault_check(void);

Bool
busfault_init(void);

#else

struct busfault;

static inline struct busfault *
busfault_register_mmap(void *addr, size_t size, busfault_notify_ptr notify, void *context)
{
    (void) addr;
    (void) size;
    (void) notify;
    (void) context;
    return NULL;
}

static inline void
busfault_unregister(struct busfault *busfault)
{
    (void) busfault;
}

static inline void busfault_check(void) {}
static inline Bool busfault_init(void) { return FALSE; }

#endif

#endif /* _BUSFAULT_H_ */
