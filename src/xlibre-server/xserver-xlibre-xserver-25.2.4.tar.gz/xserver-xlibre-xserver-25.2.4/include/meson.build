version_parts = meson.project_version().split('-') # split on prerelease
version_numbers = version_parts[0].split('.')
version_suffix = meson.project_version().replace(version_parts[0], '')
major = version_numbers[0].to_int()
minor = version_numbers[1].to_int()
patch = version_numbers[2].to_int()

# convert to the old-style 1.x.y version scheme used up to 1.20.x for backwards compatibility
release = 1 * 10000000 + major * 100000 + minor * 1000 + patch

# For feature macros we're using either false (boolean) or '1', which correspond to the macro being
# not defined at all and defined to 1. This is to match autotools behavior and thus preserve
# backwards  compatibility with all the existing code that uses #ifdef to check if feature is
# enabled. This ifdef would pass if the macro is defined to 0 which would silently break code
# in various places.
#
# As a complication when we read the configuration from conf_data back we get either string or
# bool. Meson does not like comparing things of different types so we always convert the returned
# value to an integer using to_int().
conf_data.set('MONOTONIC_CLOCK', cc.has_function('clock_gettime') and
cc.compiles('''
    #define _POSIX_C_SOURCE 200112L
    #include <time.h>
    #include <unistd.h>
    #ifndef CLOCK_MONOTONIC
    #error CLOCK_MONOTONIC not defined
    #endif
''',
    name: 'CLOCK_MONOTONIC') ? '1' : false)

conf_data.set('XSERVER_DTRACE', with_dtrace ? '1' : false)

if host_machine.endian() == 'little'
    conf_data.set('X_BYTE_ORDER', 'X_LITTLE_ENDIAN')
else
    conf_data.set('X_BYTE_ORDER', 'X_BIG_ENDIAN')
endif

# Defining _XSERVER64 on 64bit builds is VITAL, since otherwise Xlib headers
# would define lots X types (eg. Atom, XID, etc) as 64 bit, but inside the
# Xserver we really need them to be 32 bit (CARD32). When _SERVER64 is defined
# the xlib headers will typedef them exactly to CARD32.
glx_align64 = []
if cc.sizeof('unsigned long') == 8
   conf_data.set('_XSERVER64', '1')
   glx_align64 = '-D__GLX_ALIGN64'
endif

conf_data.set('_GNU_SOURCE', '1')

# autoconf checks for /dev/xf86 here, but the test should be based on
# the target, not the build system.  Could we get rid of this and just
# ifdef for openbsd?
conf_data.set('HAS_APERTURE_DRV', host_machine.system() == 'openbsd' ? '1' : false)

if get_option('input_thread') == 'false'
  enable_input_thread = false
else
  enable_input_thread = cc.has_header_symbol('pthread.h',
					     'PTHREAD_MUTEX_RECURSIVE')
  if not enable_input_thread and get_option('input_thread') == 'true'
    error('Input thread enabled and PTHREAD_MUTEX_RECURSIVE not found')
  endif
  if host_machine.system() == 'windows' and get_option('input_thread') == 'auto'
      enable_input_thread = false
  endif
endif
conf_data.set('INPUTTHREAD', enable_input_thread ? '1' : false)

if cc.compiles('''
    #define _GNU_SOURCE 1
    #include <pthread.h>
    void foo(int bar) { pthread_setname_np(pthread_self(), "example"); }
''',
    args: '-Werror-implicit-function-declaration',
    name: 'pthread_setname_np(tid, name)')
    conf_data.set('HAVE_PTHREAD_SETNAME_NP_WITH_TID', 1)
elif cc.compiles('''
    #define _GNU_SOURCE 1
    #include <pthread.h>
    void foo(int bar) { pthread_setname_np("example"); }
''',
    args: '-Werror-implicit-function-declaration',
    name: 'pthread_setname_np(name)')
    conf_data.set('HAVE_PTHREAD_SETNAME_NP_WITHOUT_TID', 1)
endif

conf_data.set('HAVE_LIBBSD', libbsd_dep.found() ? '1' : false)
# Note: this symbol is used by libXtrans.
conf_data.set('HAVE_SYSTEMD_DAEMON', build_systemd ? '1' : false)
conf_data.set('CONFIG_UDEV', build_udev ? '1' : false)
conf_data.set('CONFIG_UDEV_KMS', build_udev_kms ? '1' : false)
conf_data.set('HAVE_DBUS', build_dbus ? '1' : false)
conf_data.set('CONFIG_HAL', build_hal ? '1' : false)
conf_data.set('SEATD_LIBSEAT', build_seatd_libseat ? '1' : false)
conf_data.set('SYSTEMD_LOGIND', build_systemd_logind ? '1' : false)
conf_data.set('NEED_DBUS', build_systemd_logind or build_hal ? '1' : false)
conf_data.set('CONFIG_WSCONS', host_machine.system() in ['openbsd', 'netbsd'] ? '1' : false)

conf_data.set('HAVE_XSHMFENCE', xshmfence_dep.found() ? '1' : false)
conf_data.set('WITH_LIBDRM', libdrm_required ? '1' : false)
conf_data.set('LIBDRM_HAS_PLANE_SIZE_HINTS', libdrm_required ? libdrm_dep.version().version_compare('>= 2.4.122') : false)
conf_data.set('LIBDRM_HAS_SYNCOBJ_EVENTFD',
              libdrm_required and cc.has_function('drmSyncobjEventfd', dependencies: libdrm_dep) ? '1' : false)
conf_data.set('GLAMOR_HAS_EGL', epoxy_dep.found() ? '1' : false)
conf_data.set('GLXEXT', build_glx ? '1' : false)
conf_data.set('GLAMOR', build_glamor ? '1' : false)
conf_data.set('GLAMOR_HAS_GBM', build_gbm ? '1' : false)
conf_data.set('GBM_BO_WITH_MODIFIERS',
              build_glamor and build_gbm and gbm_dep.version().version_compare('>= 17.1') ? '1' : false)
conf_data.set('GBM_BO_FD',
              build_glamor and gbm_dep.found() and cc.has_header_symbol('gbm.h', 'gbm_bo_get_fd', dependencies : gbm_dep )  ? '1' : false)
conf_data.set('GBM_BO_FD_FOR_PLANE',
              build_glamor and build_gbm and gbm_dep.version().version_compare('>= 21.1') ? '1' : false)
conf_data.set('GBM_BO_WITH_MODIFIERS2',
              build_glamor and build_gbm and gbm_dep.version().version_compare('>= 21.3') ? '1' : false)
conf_data.set('GBM_HAVE_BO_USE_LINEAR',
              build_glamor and build_gbm and cc.has_header_symbol('gbm.h', 'GBM_BO_USE_LINEAR', dependencies : gbm_dep )  ? '1' : false)
conf_data.set('GBM_HAVE_BO_USE_FRONT_RENDERING',
              build_glamor and build_gbm and cc.has_header_symbol('gbm.h','GBM_BO_USE_FRONT_RENDERING', dependencies: gbm_dep ) ? '1' : false)

conf_data.set_quoted('SERVER_MISC_CONFIG_PATH', serverconfigdir)
conf_data.set_quoted('PROJECTROOT', get_option('prefix'))
conf_data.set_quoted('SYSCONFDIR', join_paths(get_option('prefix'), get_option('sysconfdir')))
conf_data.set_quoted('SUID_WRAPPER_DIR', join_paths(get_option('prefix'), get_option('libexecdir')))
conf_data.set_quoted('COMPILEDDEFAULTFONTPATH', default_font_path)

conf_data.set('XORG_VERSION_CURRENT', release)
conf_data.set_quoted('XLIBRE_VERSION_STRING', meson.project_version())
conf_data.set_quoted('PACKAGE_VERSION_SUFFIX', version_suffix)

conf_data.set('HASXDMAUTH', has_xdm_auth ? '1' : false)

conf_data.set('HAVE_DLFCN_H', cc.has_header('dlfcn.h') ? '1' : false)
conf_data.set('HAVE_EXECINFO_H', cc.has_header('execinfo.h') ? '1' : false)
conf_data.set('HAVE_FNMATCH_H', cc.has_header('fnmatch.h') ? '1' : false)
conf_data.set('HAVE_LINUX_AGPGART_H', cc.has_header('linux/agpgart.h') ? '1' : false)
conf_data.set('HAVE_STRINGS_H', cc.has_header('strings.h') ? '1' : false)
conf_data.set('HAVE_SYS_AGPGART_H', cc.has_header('sys/agpgart.h') ? '1' : false)
conf_data.set('HAVE_SYS_UCRED_H', cc.has_header('sys/ucred.h') ? '1' : false)
conf_data.set('HAVE_SYS_UN_H', cc.has_header('sys/un.h') ? '1' : false)
conf_data.set('HAVE_SYS_UTSNAME_H', cc.has_header('sys/utsname.h') ? '1' : false)
conf_data.set('HAVE_SYS_SYSMACROS_H', cc.has_header('sys/sysmacros.h') ? '1' : false)

conf_data.set('HAVE_ARC4RANDOM_BUF', cc.has_function('arc4random_buf', dependencies: libbsd_dep) ? '1' : false)
conf_data.set('HAVE_GETRANDOM', cc.has_function('getrandom', prefix: '#include <sys/random.h>') ? '1' : false)
conf_data.set('HAVE_BACKTRACE', cc.has_function('backtrace') ? '1' : false)
conf_data.set('HAVE_CBRT', cc.has_function('cbrt') ? '1' : false)
conf_data.set('HAVE_EPOLL_CREATE1', cc.has_function('epoll_create1',dependencies:epoll_dep, prefix:'#include<sys/epoll.h>') ? '1' : false)
conf_data.set('HAVE_GETUID', cc.has_function('getuid') ? '1' : false)
conf_data.set('HAVE_GETEUID', cc.has_function('geteuid') ? '1' : false)
conf_data.set('HAVE_ISASTREAM', cc.has_function('isastream') ? '1' : false)
conf_data.set('HAVE_ISSETUGID', cc.has_function('issetugid') ? '1' : false)
conf_data.set('HAVE_GETADDRINFO', cc.has_function('getaddrinfo') ? '1' : false)
conf_data.set('HAVE_GETIFADDRS', cc.has_function('getifaddrs') ? '1' : false)
conf_data.set('HAVE_GETPEEREID', cc.has_function('getpeereid') ? '1' : false)
conf_data.set('HAVE_GETPEERUCRED', cc.has_function('getpeerucred') ? '1' : false)
conf_data.set('HAVE_GETPROGNAME', cc.has_function('getprogname') ? '1' : false)
conf_data.set('HAVE_GETZONEID', cc.has_function('getzoneid') ? '1' : false)
conf_data.set('HAVE_INET_NTOP', cc.has_function('inet_ntop') ? '1' : false)
conf_data.set('HAVE_MEMFD_CREATE', cc.has_function('memfd_create') ? '1' : false)
conf_data.set('HAVE_MKOSTEMP', cc.has_function('mkostemp') ? '1' : false)
conf_data.set('HAVE_MMAP', cc.has_function('mmap') ? '1' : false)
conf_data.set('HAVE_OPEN_DEVICE', cc.has_function('open_device') ? '1' : false)
conf_data.set('HAVE_POLL', cc.has_function('poll') ? '1' : false)
conf_data.set('HAVE_POLLSET_CREATE', cc.has_function('pollset_create') ? '1' : false)
conf_data.set('HAVE_POSIX_FALLOCATE', cc.has_function('posix_fallocate') ? '1' : false)
conf_data.set('HAVE_PORT_CREATE', cc.has_function('port_create') ? '1' : false)
conf_data.set('HAVE_REALLOCARRAY', cc.has_function('reallocarray', dependencies: libbsd_dep) ? '1' : false)
conf_data.set('HAVE_SETEUID', cc.has_function('seteuid') ? '1' : false)
conf_data.set('HAVE_SETITIMER', cc.has_function('setitimer') ? '1' : false)
conf_data.set('HAVE_SHMCTL64', cc.has_function('shmctl64') ? '1' : false)
conf_data.set('HAVE_SIGACTION', cc.has_function('sigaction') ? '1' : false)
conf_data.set('HAVE_SIGPROCMASK', cc.has_function('sigprocmask') ? '1' : false)
# HAVE_SOCKLEN_T is used by xtrans when IPv6 is disabled
conf_data.set('HAVE_SOCKLEN_T', cc.has_type('socklen_t', prefix: '#include <sys/socket.h>') ? '1' : false)
conf_data.set('HAVE_STRCASESTR', cc.has_function('strcasestr') ? '1' : false)
conf_data.set('HAVE_STRNDUP', cc.has_function('strndup') and cc.has_header_symbol('string.h', 'strndup') ? '1' : false)
# HAVE_STRUCT_SOCKADDR_STORAGE is used by xtrans >= 1.6
conf_data.set('HAVE_STRUCT_SOCKADDR_STORAGE', cc.has_type('struct sockaddr_storage', prefix: '#include <sys/socket.h>') ? '1' : false)
conf_data.set('HAVE_TIMINGSAFE_MEMCMP', cc.has_function('timingsafe_memcmp') ? '1' : false)
conf_data.set('HAVE_VASPRINTF', cc.has_function('vasprintf') ? '1' : false)
conf_data.set('HAVE_VSNPRINTF', cc.has_function('vsnprintf') ? '1' : false)
conf_data.set('HAVE_WALKCONTEXT', cc.has_function('walkcontext') ? '1' : false)
conf_data.set('HAVE_XUCRED_CR_PID', cc.has_member('struct xucred', 'cr_pid', prefix : '#include <sys/ucred.h>') ? '1' : false)
conf_data.set('LOCK_SERVER', host_machine.system() != 'windows' ? '1' : false)

# Don't let X dependencies typedef 'pointer'
conf_data.set('_XTYPEDEF_POINTER', '1')
conf_data.set('_XITYPEDEF_POINTER', '1')

conf_data.set('LISTEN_TCP', get_option('listen_tcp'))
conf_data.set('LISTEN_UNIX', get_option('listen_unix'))
conf_data.set('LISTEN_LOCAL', get_option('listen_local'))

if cc.has_header_symbol('sys/socket.h', 'SCM_RIGHTS')
  conf_data.set('XTRANS_SEND_FDS', '1')
endif

if conf_data.get('HAVE_GETPEEREID').to_int() == 0 and conf_data.get('HAVE_GETPEERUCRED').to_int() == 0
    if not cc.has_header_symbol('sys/socket.h', 'SO_PEERCRED', args: '-D_GNU_SOURCE')
        conf_data.set('NO_LOCAL_CLIENT_CRED', 1)
    endif
endif

conf_data.set(
  'BSD44SOCKETS',
  cc.has_member(
     'struct sockaddr_in', 'sin_len',
     prefix: '''#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>''',
  )  ? '1' : false,
  description: 'Define to 1 if `struct sockaddr_in\' has a `sin_len\' member',
)

conf_data.set('UNIXCONN', '1')
conf_data.set('IPv6', build_ipv6 ? '1' : false)

# potentially tunable - needed also in places that cannot include misc.h
conf_data.set('MAXCLIENTS', 2048)

# Must be a power of 2 and <= MAXCLIENTS */
conf_data.set('DIX_LIMITCLIENTS', 256)

# Legacy NVidia drivers (390, 470) use an older ABI and expect an additional field in ScreenRec */
conf_data.set('CONFIG_LEGACY_NVIDIA_PADDING', legacy_nvidia_padding ? '1' : false)

# some drivers (eg. xf86-video-intel) still relying on this symbol being set
conf_data.set('COMPOSITE', '1')

conf_data.set('DAMAGE', '1')
conf_data.set('DBE', '1')
conf_data.set('DGA', build_dga ? '1' : false)
conf_data.set('DPMSExtension', build_dpms ? '1' : false)
conf_data.set('DRI2', build_dri2 ? '1' : false)
conf_data.set('DRI3', build_dri3 ? '1' : false)
if build_glx
    if build_glx_dri
        conf_data.set_quoted('DRI_DRIVER_PATH', dri_dep.get_variable(pkgconfig : 'dridriverdir'))
        conf_data.set('BUILD_GLX_DRI', 1)
    endif
endif
conf_data.set('MITSHM', build_mitshm ? '1' : false)
conf_data.set('CONFIG_MITSHM', build_mitshm ? '1' : false)

# for backwards compat with drivers, still setting the old PANORAMIX symbol
conf_data.set('PANORAMIX', build_xinerama ? '1' : false)
conf_data.set('XINERAMA', build_xinerama ? '1' : false)

conf_data.set('PRESENT', '1')
conf_data.set('RANDR', '1')
conf_data.set('RES', build_res ? '1' : false)
conf_data.set('RENDER', '1')
conf_data.set('SCREENSAVER', build_screensaver ? '1' : false)
conf_data.set('SHAPE', '1')
conf_data.set('XACE', '1')
conf_data.set('XCMISC', '1')
conf_data.set('XCSECURITY', build_xsecurity ? '1' : false)
conf_data.set('CONFIG_NAMESPACE', build_namespace ? '1' : false)
conf_data.set('XDMCP', build_xdmcp ? '1' : false)
conf_data.set('XF86BIGFONT', build_xf86bigfont ? '1' : false)
conf_data.set('XF86DRI', build_dri1 ? '1' : false)
conf_data.set('XF86VIDMODE', 1)
conf_data.set('XFIXES', '1')
conf_data.set('XFreeXDGA', build_dga ? '1' : false)
conf_data.set('XINERAMA', build_xinerama ? '1' : false)
conf_data.set('XINPUT', '1')
conf_data.set('XRECORD', '1')
conf_data.set('XSELINUX', build_xselinux ? '1' : false)
conf_data.set('XSYNC', '1')
conf_data.set('XTEST', '1')
conf_data.set('XV', build_xv ? '1' : false)
conf_data.set('XvExtension', build_xv ? '1' : false)
conf_data.set('XvMCExtension', build_xvmc ? '1' : false)

# needed by several extensions
build_registry_resource = (build_xselinux or build_res or build_namespace)
conf_data.set('X_REGISTRY_RESOURCE', build_registry_resource ? '1' : false)
build_registry_request = (build_xselinux or build_xsecurity or with_dtrace or build_namespace)
conf_data.set('X_REGISTRY_REQUEST', build_registry_request ? '1' : false)

conf_data.set('HAVE_SHA1_IN_' + sha1.to_upper(), '1', description: 'Use @0@ SHA1 functions'.format(sha1))
conf_data.set('HAVE_LIBUNWIND', get_option('libunwind'))

conf_data.set('HAVE_APM', (build_apm or build_acpi) ? '1' : false)
conf_data.set('HAVE_ACPI', build_acpi ? '1' : false)

enable_debugging = get_option('buildtype') == 'debug'
conf_data.set('DEBUG', enable_debugging ? '1' : false)

if build_rootless
    conf_data.set('ROOTLESS', build_rootless ? '1' : false)
    conf_data.set('ROOTLESS_WORKAROUND', 1)
    conf_data.set('ROOTLESS_SAFEALPHA', 1)
endif

#
# for xorg-server.h only
#
defines_svr4 = '''#if !defined(SVR4) && !defined(__svr4__) && !defined(__SVR4)
#error "I am not SVR4"
#endif
'''

# BSD specifics
supports_pcvt = false
supports_syscons = false
supports_wscons = false
csrg_based = false

if host_machine.system() == 'freebsd' or host_machine.system() == 'dragonfly'
  supports_pcvt = true
  supports_syscons = true
  csrg_based = true
endif

if host_machine.system() == 'kfreebsd'
  supports_pcvt = true
  supports_syscons = true
endif

if host_machine.system() == 'netbsd'
  supports_pcvt = true
  supports_wscons = true
  csrg_based = true
endif

if host_machine.system() == 'openbsd'
  supports_pcvt = true
  supports_wscons = true
  csrg_based = true
endif

if host_machine.system() == 'darwin'
  csrg_based = true
endif

conf_data.set('SVR4', cc.compiles(defines_svr4) ? '1' : false)
conf_data.set_quoted('XKB_DFLT_RULES', get_option('xkb_default_rules'))
conf_data.set('XORGSERVER', build_xorg ? '1' : false)
conf_data.set_quoted('XCONFIGFILE', 'xorg.conf')
conf_data.set_quoted('__XSERVERNAME__', 'Xorg')
conf_data.set('WITH_VGAHW', build_vgahw ? '1' : false)
conf_data.set('CSRG_BASED', csrg_based ? '1' : false)
conf_data.set('PCVT_SUPPORT', supports_pcvt ? '1' : false)
conf_data.set('SYSCONS_SUPPORT', supports_syscons ? '1' : false)
conf_data.set('WSCONS_SUPPORT', supports_wscons ? '1' : false)
conf_data.set('XSERVER_LIBPCIACCESS', get_option('pciaccess') ? '1' : false)
if get_option('pciaccess')
    pciaccess_dep = dependency('pciaccess', required: build_xorg)
    conf_data.set('HAVE_PCI_DEVICE_IS_BOOT_DISPLAY',
                  cc.has_function('pci_device_is_boot_display', dependencies: pciaccess_dep) ? '1' : false)
endif
conf_data.set('XSERVER_PLATFORM_BUS', build_udev_kms ? '1' : false)
conf_data.set('XSERVER_SCREEN_VRR', '1')

conf_data.set_quoted('DEFAULT_LOGDIR', log_dir)

version_data = configuration_data()
version_data.set('VENDOR_RELEASE', '@0@'.format(release))
version_data.set_quoted('VENDOR_MAN_VERSION', 'Version @0@'.format(meson.project_version()))
configure_file(output : 'version-config.h',
               configuration : version_data)

xkb_data = configuration_data()

xkb_data.set_quoted('XKB_BIN_DIRECTORY', xkb_bin_dir)
xkb_data.set_quoted('XKB_BASE_DIRECTORY', xkb_dir)
xkb_data.set_quoted('XKB_DFLT_RULES', get_option('xkb_default_rules'))
xkb_data.set_quoted('XKB_DFLT_MODEL', get_option('xkb_default_model'))
xkb_data.set_quoted('XKB_DFLT_LAYOUT', get_option('xkb_default_layout'))
xkb_data.set_quoted('XKB_DFLT_VARIANT', get_option('xkb_default_variant'))
xkb_data.set_quoted('XKB_DFLT_OPTIONS', get_option('xkb_default_options'))
xkb_data.set_quoted('XKM_OUTPUT_DIR', xkb_output_dir + '/')

configure_file(output : 'xkb-config.h',
               configuration : xkb_data)

xorg_data = configuration_data()

xorg_data.set_quoted('XORG_BIN_DIRECTORY', get_option('bindir'))
xorg_data.set('XORG_VERSION_CURRENT', release)
xorg_data.set_quoted('XF86CONFIGFILE', 'xorg.conf')
xorg_data.set_quoted('XCONFIGFILE', 'xorg.conf')
xorg_data.set_quoted('XCONFIGDIR', 'xorg.conf.d')
xorg_data.set_quoted('DEFAULT_XDG_STATE_HOME', '.local/state')
xorg_data.set_quoted('DEFAULT_XDG_STATE_HOME_LOGDIR', 'xorg')
xorg_data.set_quoted('DEFAULT_LOGDIR', log_dir)
xorg_data.set_quoted('DEFAULT_LOGPREFIX', 'Xorg.')
xorg_data.set_quoted('DEFAULT_MODULE_PATH', join_paths(get_option('prefix'), module_dir))
xorg_data.set_quoted('DEFAULT_LIBRARY_PATH', join_paths(get_option('prefix'), get_option('libdir')))
xorg_data.set_quoted('__XSERVERNAME__', 'Xorg')
xorg_data.set('XSERVER_LIBPCIACCESS', get_option('pciaccess') ? '1' : false)
xorg_data.set_quoted('PCI_TXT_IDS_PATH', '')
xorg_data.set('XSERVER_PLATFORM_BUS', build_udev_kms ? '1' : false)
xorg_data.set('WSCONS_SUPPORT',
              host_machine.system() == 'netbsd' or host_machine.system() == 'openbsd' ? '1' : false)
xorg_data.set('HAVE_STROPTS_H', cc.has_header('stropts.h') ? '1' : false)
xorg_data.set('HAVE_SYS_KD_H', cc.has_header('sys/kd.h') ? '1' : false)
xorg_data.set('HAVE_SYS_VT_H', cc.has_header('sys/vt.h') ? '1' : false)
xorg_data.set('HAVE_MODESETTING_DRIVER', build_modesetting ? '1' : false)

if host_machine.system() == 'freebsd' or host_machine.system() == 'dragonfly'
    if host_machine.cpu_family() == 'x86' or host_machine.cpu_family() == 'x86_64' or host_machine.cpu_family() == 'aarch64'
        xorg_data.set('USE_DEV_IO', '1')
    endif
elif host_machine.system() == 'netbsd' or host_machine.system() == 'openbsd'
    if host_machine.cpu_family() == 'x86'
        xorg_data.set('USE_I386_IOPL', '1')
    endif
    if host_machine.cpu_family() == 'x86_64'
        xorg_data.set('USE_AMD64_IOPL', '1')
    endif
endif

xwin_data = configuration_data()
xwin_data.set('HAS_DEVWINDOWS', host_machine.system() == 'cygwin' ? '1' : false,
              description: 'Has /dev/windows for signaling new win32 messages')
xwin_data.set('RELOCATE_PROJECTROOT', host_machine.system() == 'windows' ? '1' : false,
              description: 'Make paths relative to the xserver installation location')
xwin_data.set10('ENABLE_DEBUG', enable_debugging)

configure_file(output : 'xwin-config.h',
               input : 'xwin-config.h.meson.in',
               configuration : xwin_data)

dtrace_hdr = []
dtrace_tmpl = files('Xserver.d')
if with_dtrace
    dtrace_header = generator(dtrace,
        output: '@BASENAME@-dtrace.h',
        arguments: ['-h', '-s', '@INPUT@', '-o', '@OUTPUT@']
    )

    dtrace_hdr += dtrace_header.process(dtrace_tmpl)
endif

if build_xorg_sdk
    install_data(
        [
            'Xprintf.h',
            'callback.h',
            'colormap.h',
            'colormapst.h',
            'compiler.h',
            'compositeext.h',
            'cursor.h',
            'cursorstr.h',
            'damage.h',
            'damagestr.h',
            'dix.h',
            'dixaccess.h',
            'dixfont.h',
            'dixfontstr.h',
            'dixstruct.h',
            'dri.h',
            'dri2.h',
            'dri3.h',
            'dristruct.h',
            'edid.h',
            'events.h',
            'exa.h',
            'exevents.h',
            'extension.h',
            'extinit.h',
            'extnsionst.h',
            'fb.h',
            'fbdevhw.h',
            'fboverlay.h',
            'fbpict.h',
            'fbrop.h',
            'wfbrename.h',
            'fd_notify.h',
            'fourcc.h',
            'gc.h',
            'gcstruct.h',
            'glamor.h',
            'globals.h',
            'glxvndabi.h',
            'xf86i2c.h',
            'i2c_def.h',
            'input.h',
            'inputstr.h',
            'list.h',
            'micmap.h',
            'micoord.h',
            'migc.h',
            'mi.h',
            'miline.h',
            'mioverlay.h',
            'mipointer.h',
            'mipointrst.h',
            'mistruct.h',
            'mizerarc.h',
            'misc.h',
            'miscstruct.h',
            'misync.h',
            'misyncfd.h',
            'misyncshm.h',
            'misyncstr.h',
            'opaque.h',
            'optionstr.h',
            'os.h',
            'glyphstr.h',
            'mipict.h',
            'picture.h',
            'picturestr.h',
            'present.h',
            'pixmap.h',
            'pixmapstr.h',
            'privates.h',
            'property.h',
            'ptrveloc.h',
            'randrstr.h',
            'rrtransform.h',
            'region.h',
            'regionstr.h',
            'resource.h',
            'rgb.h',
            'sarea.h',
            'screenint.h',
            'scrnintstr.h',
            'servermd.h',
            'shadow.h',
            'shadowfb.h',
            'syncsdk.h',
            'validate.h',
            'displaymode.h',
            'vndserver.h',
            'window.h',
            'windowstr.h',
            'vgaHW.h',
            'xaarop.h',
            'xf86.h',
            'xf86cmap.h',
            'xf86Cursor.h',
            'xf86DDC.h',
            'xf86fbman.h',
            'xf86Opt.h',
            'xf86Optionstr.h',
            'xf86platformBus.h',
            'xf86Parser.h',
            'xf86Optrec.h',
            'xf86Priv.h',
            'xf86Privstr.h',
            'xf86str.h',
            'xf86Module.h',
            'xf86Xinput.h',
            'xf86sbusBus.h',
            'xf86Pci.h',
            'xf86_OSlib.h',
            'xf86_OSproc.h',
            'xisb.h',
            'xkbsrv.h',
            'xkbstr.h',
            'xkbrules.h',
            'xorgVersion.h',
            'Xprintf.h',
            'xvdix.h',
            'xvmcext.h',
            'xserver-properties.h',
            'xlibre_ptrtypes.h',
            'xf86Crtc.h',
            'xf86Modes.h',
            'xf86RandR12.h',
        ],
        install_dir: xorgsdkdir,
    )

    if build_dga
        install_data(['dgaproc.h'], install_dir: xorgsdkdir)
    endif

    if build_xv
        install_data(['xf86xv.h', 'xf86xvmc.h'], install_dir: xorgsdkdir)
    endif

    if build_mitshm
        install_data(['shmint.h'], install_dir: xorgsdkdir)
    endif

    if int10 != 'false'
        install_data(['xf86int10.h', 'vbe.h', 'vbeModes.h'], install_dir: xorgsdkdir)
    endif
endif
