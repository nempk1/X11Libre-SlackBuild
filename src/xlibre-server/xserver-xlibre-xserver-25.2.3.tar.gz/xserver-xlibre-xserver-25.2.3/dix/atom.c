/***********************************************************

Copyright 1987, 1998  The Open Group

Permission to use, copy, modify, distribute, and sell this software and its
documentation for any purpose is hereby granted without fee, provided that
the above copyright notice appear in all copies and that both that
copyright notice and this permission notice appear in supporting
documentation.

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
OPEN GROUP BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of The Open Group shall not be
used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization from The Open Group.

Copyright 1987 by Digital Equipment Corporation, Maynard, Massachusetts.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of Digital not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

DIGITAL DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
DIGITAL BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

******************************************************************/

#include <dix-config.h>

#include <stdio.h>
#include <string.h>
#include <X11/X.h>
#include <X11/Xatom.h>

#include "dix/atom_priv.h"
#include "dix/dix_priv.h"
#include "include/misc.h"

#include "resource.h"
#include "dix.h"

#define InitialTableSize 256

typedef struct _Node {
    struct _Node *left, *right;
    Atom a;
    unsigned int fingerPrint;
    const char *string;
} NodeRec, *NodePtr;

static Atom lastAtom = None;
static NodePtr atomRoot = NULL;
static unsigned long tableLength;
static NodePtr *nodeTable;

Atom
MakeAtom(const char *string, unsigned len, Bool makeit)
{
    NodePtr *np = &atomRoot;
    unsigned int fp = 0;
    for (unsigned int i = 0; i < (len + 1) / 2; i++) {
        fp = fp * 27 + (unsigned int)string[i];
        fp = fp * 27 + (unsigned int)string[len - 1 - i];
    }
    while (*np != NULL) {
        if (fp < (*np)->fingerPrint)
            np = &((*np)->left);
        else if (fp > (*np)->fingerPrint)
            np = &((*np)->right);
        else {                  /* now start testing the strings */
            int comp = strncmp(string, (*np)->string, len);
            if ((comp < 0) || ((comp == 0) && (len < strlen((*np)->string))))
                np = &((*np)->left);
            else if (comp > 0)
                np = &((*np)->right);
            else
                return (*np)->a;
        }
    }
    if (makeit) {
        NodePtr nd = calloc(1, sizeof(NodeRec));
        if (!nd)
            return BAD_RESOURCE;
        if (lastAtom < XA_LAST_PREDEFINED) {
            nd->string = string;
        }
        else {
            nd->string = strndup(string, len);
            if (!nd->string) {
                free(nd);
                return BAD_RESOURCE;
            }
        }
        if ((lastAtom + 1) >= tableLength) {
            NodePtr *table;

            table = reallocarray(nodeTable, tableLength, 2 * sizeof(NodePtr));
            if (!table) {
                if (nd->string != string) {
                    /* nd->string has been strdup'ed */
                    free((char *) nd->string);
                }
                free(nd);
                return BAD_RESOURCE;
            }
            tableLength <<= 1;
            nodeTable = table;
        }
        *np = nd;
        nd->left = nd->right = NULL;
        nd->fingerPrint = fp;
        nd->a = ++lastAtom;
        nodeTable[lastAtom] = nd;
        return nd->a;
    }
    else
        return None;
}

Bool
ValidAtom(Atom atom)
{
    return (atom != None) && (atom <= lastAtom);
}

const char *
NameForAtom(Atom atom)
{
    if (atom > lastAtom)
        return 0;

    if (nodeTable[atom] == NULL)
        return 0;

    return nodeTable[atom]->string;
}

static void
FreeAtom(NodePtr patom)
{
    if (patom->left)
        FreeAtom(patom->left);
    if (patom->right)
        FreeAtom(patom->right);
    if (patom->a > XA_LAST_PREDEFINED) {
        /*
         * All strings above XA_LAST_PREDEFINED are strdup'ed, so it's safe to
         * cast here
         */
        free((char *) patom->string);
    }
    free(patom);
}

void
FreeAllAtoms(void)
{
    if (atomRoot == NULL)
        return;
    FreeAtom(atomRoot);
    atomRoot = NULL;
    free(nodeTable);
    nodeTable = NULL;
    lastAtom = None;
}

void
InitAtoms(void)
{
    FreeAllAtoms();
    tableLength = InitialTableSize;
    nodeTable = calloc(InitialTableSize, sizeof(NodePtr));
    if (!nodeTable)
        FatalError("creating atom table");
    nodeTable[None] = NULL;
    MakePredeclaredAtoms();
    if (lastAtom != XA_LAST_PREDEFINED)
        FatalError("builtin atom number mismatch");
}
