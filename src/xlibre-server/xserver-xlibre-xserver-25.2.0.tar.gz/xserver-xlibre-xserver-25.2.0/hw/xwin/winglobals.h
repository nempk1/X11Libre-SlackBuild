/*
  File: winglobals.h
  Purpose: declarations for global variables

  Permission is hereby granted, free of charge, to any person obtaining a
  copy of this software and associated documentation files (the "Software"),
  to deal in the Software without restriction, including without limitation
  the rights to use, copy, modify, merge, publish, distribute, sublicense,
  and/or sell copies of the Software, and to permit persons to whom the
  Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice (including the next
  paragraph) shall be included in all copies or substantial portions of the
  Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THE SOFTWARE.

*/
#ifndef WINGLOBALS_H
#define WINGLOBALS_H

#include <pthread.h>
#include <stdbool.h>

/*
 * References to external symbols
 */

extern int g_iNumScreens;
extern int g_iLastScreen;
extern char *g_pszCommandLine;
extern bool g_fSilentFatalError;
extern const char *g_pszLogFile;

#ifdef RELOCATE_PROJECTROOT
extern bool g_fLogFileChanged;
#endif
extern int g_iLogVerbose;
extern bool g_fLogInited;

extern bool g_fAuthEnabled;
extern bool g_fXdmcpEnabled;
extern bool g_fCompositeAlpha;

extern bool g_fNoHelpMessageBox;
extern bool g_fNativeGl;
extern bool g_fHostInTitle;

extern HWND g_hDlgDepthChange;
extern HWND g_hDlgExit;
extern HWND g_hDlgAbout;

extern bool g_fSoftwareCursor;
extern bool g_fCursor;

/* Typedef for DIX wrapper functions */
typedef int (*winDispatchProcPtr) (ClientPtr);

/*
 * Wrapped DIX functions
 */
extern winDispatchProcPtr winProcEstablishConnectionOrig;
extern bool g_fClipboard;
extern bool g_fClipboardStarted;

/* The global X default icons */
extern HICON g_hIconX;
extern HICON g_hSmallIconX;

extern DWORD g_dwCurrentThreadID;

extern bool g_fKeyboardHookLL;
extern bool g_fButton[3];

extern pthread_mutex_t g_pmTerminating;

#endif                          /* WINGLOBALS_H */
